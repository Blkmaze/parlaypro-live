
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/api.mjs
var SITE_ID = "d6f0d30b-ccaa-461e-9973-f13ee862343b";
var STORE = "sq3";
var ADMIN_PIN = process.env.ADMIN_PIN || "2826";
var MASTER_PIN = process.env.MASTER_PIN || "0614";
var ORIGIN = "https://parlaypro-live.netlify.app";
var STRIPE_SK = process.env.STRIPE_SECRET_KEY;
var STRIPE_WH = process.env.STRIPE_WEBHOOK_SECRET;
function corsHeaders(req) {
  var origin = req.headers.get("origin") || "";
  var allowed = origin === ORIGIN || origin === "http://localhost:8888";
  return { "Content-Type": "application/json", "Access-Control-Allow-Origin": allowed ? origin : ORIGIN, "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, stripe-signature", "X-Content-Type-Options": "nosniff" };
}
function json(req, data, status) {
  return new Response(JSON.stringify(data), { status: status || 200, headers: corsHeaders(req) });
}
function validPin(p) {
  return p === ADMIN_PIN || p === MASTER_PIN;
}
function sanitizeGameId(raw) {
  if (typeof raw !== "string") return null;
  var c = raw.replace(/[^A-Za-z0-9_\-]/g, "").slice(0, 64);
  return c.length >= 3 ? c : null;
}
function sanitizeInitials(raw) {
  if (typeof raw !== "string") return null;
  var c = raw.replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 4);
  return c.length >= 2 ? c : null;
}
function sanitizeSport(raw) {
  var a = ["ncaam", "ncaaw", "nba", "wnba", "nhl", "mlb", "nfl", "mls"];
  return a.indexOf(raw) !== -1 ? raw : "nba";
}
async function blobGet(token, key) {
  var r = await fetch("https://api.netlify.com/api/v1/blobs/" + SITE_ID + "/" + STORE + "/" + encodeURIComponent(key), { headers: { Authorization: "Bearer " + token } });
  if (!r.ok) return null;
  var t = await r.text();
  try {
    return JSON.parse(t);
  } catch (e) {
    return null;
  }
}
async function blobSet(token, key, value) {
  var r = await fetch("https://api.netlify.com/api/v1/blobs/" + SITE_ID + "/" + STORE + "/" + encodeURIComponent(key), { method: "PUT", headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" }, body: JSON.stringify(value) });
  if (!r.ok) throw new Error("Blob write failed: " + r.status);
}
async function verifyStripe(payload, sigHeader, secret) {
  try {
    var parts = {};
    sigHeader.split(",").forEach(function(p) {
      var kv = p.split("=");
      parts[kv[0]] = kv[1];
    });
    var ts = parts["t"];
    var sig = parts["v1"];
    if (!ts || !sig) return false;
    var enc = new TextEncoder();
    var key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    var mac = await crypto.subtle.sign("HMAC", key, enc.encode(ts + "." + payload));
    var hex = Array.from(new Uint8Array(mac)).map(function(b) {
      return b.toString(16).padStart(2, "0");
    }).join("");
    return hex === sig;
  } catch (e) {
    return false;
  }
}
var empty = function() {
  return { owners: {}, pending: {}, rowNums: null, colNums: null, numbersLocked: false };
};
async function handler(req, context) {
  var url = new URL(req.url);
  var path = url.pathname;
  var method = req.method.toUpperCase();
  if (method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(req) });
  var body = {};
  var rawBody = "";
  if (method === "POST") {
    try {
      rawBody = await req.text();
      body = JSON.parse(rawBody);
    } catch (e) {
      body = {};
    }
  }
  var token = process.env.NETLIFY_TOKEN;
  if (path === "/api/scores" && method === "GET") {
    var SPORTS = { ncaam: "https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/scoreboard", ncaaw: "https://site.api.espn.com/apis/site/v2/sports/basketball/womens-college-basketball/scoreboard", nba: "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard", wnba: "https://site.api.espn.com/apis/site/v2/sports/basketball/wnba/scoreboard", nhl: "https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard", mlb: "https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard", nfl: "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard", mls: "https://site.api.espn.com/apis/site/v2/sports/soccer/usa.1/scoreboard" };
    var sport = sanitizeSport(url.searchParams.get("sport"));
    var date = (url.searchParams.get("date") || "").replace(/[^0-9]/g, "").slice(0, 8);
    var espnUrl = date ? SPORTS[sport] + "?dates=" + date : SPORTS[sport];
    try {
      var res = await fetch(espnUrl);
      var edata = await res.json();
      var games = (edata.events || []).map(function(e) {
        var c = e.competitions && e.competitions[0];
        var home = c && c.competitors && c.competitors.find(function(t) {
          return t.homeAway === "home";
        });
        var away = c && c.competitors && c.competitors.find(function(t) {
          return t.homeAway === "away";
        });
        var s = c && c.status && c.status.type;
        var odds = c && c.odds && c.odds[0];
        return { id: e.id, name: e.name, home: home && home.team && home.team.abbreviation || "", homeFull: home && home.team && home.team.displayName || "", homeLogo: home && home.team && home.team.logo || "", homeScore: home && home.score || "0", away: away && away.team && away.team.abbreviation || "", awayFull: away && away.team && away.team.displayName || "", awayLogo: away && away.team && away.team.logo || "", awayScore: away && away.score || "0", status: s && s.completed ? "FINAL" : s && s.inProgress ? "LIVE" : "SCHEDULED", clock: c && c.status && c.status.displayClock || "", period: c && c.status && c.status.period || 0, time: e.date ? new Date(e.date).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone: "America/New_York" }) + " ET" : "", date: e.date ? new Date(e.date).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric", timeZone: "America/New_York" }) : "", spread: odds && odds.spread || null, total: odds && odds.overUnder || null, awayML: odds && odds.awayTeamOdds && odds.awayTeamOdds.moneyLine || null, homeML: odds && odds.homeTeamOdds && odds.homeTeamOdds.moneyLine || null, spreadFav: odds && odds.homeTeamOdds && odds.homeTeamOdds.favorite ? "home" : "away" };
      });
      return json(req, { sport, games });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/create-checkout" && method === "POST") {
    if (!STRIPE_SK) return json(req, { error: "Stripe not configured" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var initials = sanitizeInitials(body.initials);
    var qty = parseInt(body.qty, 10);
    var priceEa = parseInt(body.priceEach, 10) || 1e3;
    if (!gameId) return json(req, { error: "Invalid gameId" }, 400);
    if (!initials) return json(req, { error: "Invalid initials" }, 400);
    if (!qty || qty < 1 || qty > 10) return json(req, { error: "Qty must be 1-10" }, 400);
    var successUrl = ORIGIN + "?payment=success&gameId=" + gameId + "&initials=" + initials + "&qty=" + qty;
    var cancelUrl = ORIGIN + "?payment=cancelled";
    try {
      var sr = await fetch("https://api.stripe.com/v1/checkout/sessions", { method: "POST", headers: { Authorization: "Bearer " + STRIPE_SK, "Content-Type": "application/x-www-form-urlencoded" }, body: ["mode=payment", "line_items[0][price_data][currency]=usd", "line_items[0][price_data][product_data][name]=" + encodeURIComponent("ParlayPro Square x" + qty), "line_items[0][price_data][product_data][description]=" + encodeURIComponent("Square for " + initials), "line_items[0][price_data][unit_amount]=" + priceEa, "line_items[0][quantity]=" + qty, "success_url=" + encodeURIComponent(successUrl), "cancel_url=" + encodeURIComponent(cancelUrl), "metadata[gameId]=" + encodeURIComponent(gameId), "metadata[initials]=" + encodeURIComponent(initials), "metadata[qty]=" + qty].join("&") });
      var session = await sr.json();
      if (!sr.ok) return json(req, { error: session.error && session.error.message || "Stripe error" }, 500);
      return json(req, { url: session.url });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/stripe-webhook" && method === "POST") {
    var sig = req.headers.get("stripe-signature") || "";
    if (!STRIPE_WH) return json(req, { error: "Webhook secret not set" }, 500);
    var valid = await verifyStripe(rawBody, sig, STRIPE_WH);
    if (!valid) return json(req, { error: "Invalid signature" }, 400);
    try {
      var event = JSON.parse(rawBody);
      if (event.type === "checkout.session.completed") {
        var meta = event.data.object.metadata || {};
        var gid = sanitizeGameId(meta.gameId);
        var ini = sanitizeInitials(meta.initials);
        var qty2 = parseInt(meta.qty, 10) || 1;
        if (gid && ini && token) {
          var d = await blobGet(token, gid) || empty();
          var ow = d.owners || {};
          var pe = d.pending || {};
          var conf = [];
          Object.keys(pe).forEach(function(idx) {
            var p = pe[idx];
            if (p && p.initials === ini && conf.length < qty2) {
              ow[parseInt(idx)] = ini;
              delete pe[parseInt(idx)];
              conf.push(parseInt(idx));
            }
          });
          if (conf.length < qty2) {
            var op = [];
            for (var i = 0; i < 100; i++) {
              if (ow[i] === void 0 && pe[i] === void 0) op.push(i);
            }
            for (var i = op.length - 1; i > 0; i--) {
              var j = Math.floor(Math.random() * (i + 1));
              var tmp = op[i];
              op[i] = op[j];
              op[j] = tmp;
            }
            op.slice(0, qty2 - conf.length).forEach(function(idx) {
              ow[idx] = ini;
              conf.push(idx);
            });
          }
          d.owners = ow;
          d.pending = pe;
          await blobSet(token, gid, d);
        }
      }
      return json(req, { received: true });
    } catch (e) {
      return json(req, { error: "Webhook error" }, 500);
    }
  }
  if (path === "/api/squares" && method === "GET") {
    var gameId = sanitizeGameId(url.searchParams.get("gameId"));
    if (!gameId) return json(req, { error: "Invalid gameId" }, 400);
    if (!token) return json(req, empty());
    try {
      var data = await blobGet(token, gameId) || empty();
      return json(req, data);
    } catch (e) {
      return json(req, empty());
    }
  }
  if (path === "/api/auto-assign" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var initials = sanitizeInitials(body.initials);
    var qty = parseInt(body.qty, 10);
    var isPending = !!body.pending;
    var payMethod = ["cash", "cashapp", "paypal"].indexOf(body.payMethod) !== -1 ? body.payMethod : "unknown";
    var amount = typeof body.amount === "string" ? body.amount.replace(/[^0-9.]/g, "").slice(0, 8) : "?";
    if (!gameId) return json(req, { error: "Invalid gameId" }, 400);
    if (!initials) return json(req, { error: "Invalid initials" }, 400);
    if (!qty || qty < 1 || qty > 10) return json(req, { error: "Qty must be 1-10" }, 400);
    try {
      var data = await blobGet(token, gameId) || empty();
      var owners = data.owners || {};
      var pending = data.pending || {};
      var open = [];
      for (var i = 0; i < 100; i++) {
        if (owners[i] === void 0 && pending[i] === void 0) open.push(i);
      }
      if (!open.length) return json(req, { error: "No open squares" }, 409);
      for (var i = open.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var tmp = open[i];
        open[i] = open[j];
        open[j] = tmp;
      }
      var assigned = open.slice(0, Math.min(qty, open.length));
      if (isPending) {
        assigned.forEach(function(idx) {
          pending[idx] = { initials, payMethod, amount };
        });
        data.pending = pending;
      } else {
        assigned.forEach(function(idx) {
          owners[idx] = initials;
        });
        data.owners = owners;
      }
      await blobSet(token, gameId, data);
      return json(req, { ok: true, indices: assigned, initials });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/claim-square" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var initials = sanitizeInitials(body.initials);
    var indices = Array.isArray(body.indices) ? body.indices.filter(function(i2) {
      return Number.isInteger(i2) && i2 >= 0 && i2 < 100;
    }) : [];
    var isPending = !!body.pending;
    var payMethod = ["cash", "cashapp", "paypal"].indexOf(body.payMethod) !== -1 ? body.payMethod : "unknown";
    var amount = typeof body.amount === "string" ? body.amount.replace(/[^0-9.]/g, "").slice(0, 8) : "?";
    if (!gameId) return json(req, { error: "Invalid gameId" }, 400);
    if (!initials) return json(req, { error: "Invalid initials" }, 400);
    if (!indices.length) return json(req, { error: "No valid indices" }, 400);
    try {
      var data = await blobGet(token, gameId) || empty();
      var owners = data.owners || {};
      var pending = data.pending || {};
      var conflicts = indices.filter(function(i2) {
        return owners[i2] !== void 0 || pending[i2] !== void 0;
      });
      if (conflicts.length) return json(req, { error: "Already taken: " + conflicts.join(", ") }, 409);
      if (isPending) {
        indices.forEach(function(i2) {
          pending[i2] = { initials, payMethod, amount };
        });
        data.pending = pending;
      } else {
        indices.forEach(function(i2) {
          owners[i2] = initials;
        });
        data.owners = owners;
      }
      await blobSet(token, gameId, data);
      return json(req, { ok: true, claimed: indices, initials });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/init-numbers" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var rowNums = Array.isArray(body.rowNums) && body.rowNums.length === 10 ? body.rowNums : null;
    var colNums = Array.isArray(body.colNums) && body.colNums.length === 10 ? body.colNums : null;
    if (!gameId || !rowNums || !colNums) return json(req, { error: "Missing fields" }, 400);
    try {
      var data = await blobGet(token, gameId) || empty();
      if (!data.rowNums) {
        data.rowNums = rowNums;
        data.colNums = colNums;
        await blobSet(token, gameId, data);
        return json(req, { ok: true, stored: true, rowNums, colNums });
      }
      return json(req, { ok: true, stored: false, rowNums: data.rowNums, colNums: data.colNums });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/lock-numbers" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var pin = typeof body.pin === "string" ? body.pin.slice(0, 8) : "";
    if (!gameId || !pin) return json(req, { error: "Missing fields" }, 400);
    if (!validPin(pin)) return json(req, { error: "Invalid PIN" }, 403);
    try {
      var data = await blobGet(token, gameId) || empty();
      if (body.rowNums) data.rowNums = body.rowNums;
      if (body.colNums) data.colNums = body.colNums;
      data.numbersLocked = true;
      await blobSet(token, gameId, data);
      return json(req, { ok: true });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/reset-squares" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var pin = typeof body.pin === "string" ? body.pin.slice(0, 8) : "";
    if (!gameId || !pin) return json(req, { error: "Missing fields" }, 400);
    if (!validPin(pin)) return json(req, { error: "Invalid PIN" }, 403);
    try {
      await blobSet(token, gameId, { owners: {}, pending: {}, rowNums: null, colNums: null, numbersLocked: false, resetAt: Date.now() });
      return json(req, { ok: true });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/confirm-pending" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var pin = typeof body.pin === "string" ? body.pin.slice(0, 8) : "";
    if (!gameId) return json(req, { error: "Missing gameId" }, 400);
    if (!validPin(pin)) return json(req, { error: "Invalid PIN" }, 403);
    try {
      var data = await blobGet(token, gameId) || empty();
      var owners = data.owners || {};
      var pending = data.pending || {};
      var confirmed = [];
      var indices = Array.isArray(body.indices) ? body.indices : Object.keys(pending).map(Number);
      indices.forEach(function(i2) {
        var p = pending[i2];
        if (p) {
          owners[i2] = p.initials;
          delete pending[i2];
          confirmed.push(i2);
        }
      });
      data.owners = owners;
      data.pending = pending;
      await blobSet(token, gameId, data);
      return json(req, { ok: true, confirmed });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  if (path === "/api/reject-pending" && method === "POST") {
    if (!token) return json(req, { error: "Server error" }, 500);
    var gameId = sanitizeGameId(body.gameId);
    var pin = typeof body.pin === "string" ? body.pin.slice(0, 8) : "";
    if (!gameId || !pin) return json(req, { error: "Missing fields" }, 400);
    if (!validPin(pin)) return json(req, { error: "Invalid PIN" }, 403);
    try {
      var data = await blobGet(token, gameId) || empty();
      var pending = data.pending || {};
      var indices = Array.isArray(body.indices) ? body.indices : Object.keys(pending).map(Number);
      indices.forEach(function(i2) {
        delete pending[i2];
      });
      data.pending = pending;
      await blobSet(token, gameId, data);
      return json(req, { ok: true });
    } catch (e) {
      return json(req, { error: "Server error" }, 500);
    }
  }
  return json(req, { error: "Not found" }, 404);
}
var config = { path: ["/api/scores", "/api/squares", "/api/claim-square", "/api/auto-assign", "/api/init-numbers", "/api/lock-numbers", "/api/reset-squares", "/api/confirm-pending", "/api/reject-pending", "/api/create-checkout", "/api/stripe-webhook"] };
export {
  config,
  handler as default
};
